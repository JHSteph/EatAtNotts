package com.example.eatatnotts.History

data class HistoryDateItem(//Data to house information of History Date
    val date:String?=null
)
