package com.example.eatatnotts.MyHistory

data class MyHistoryDateItem (//Data to house information of My History Date
    val date:String?=null
)