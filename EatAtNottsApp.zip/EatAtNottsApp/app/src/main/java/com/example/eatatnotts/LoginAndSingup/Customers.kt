package com.example.eatatnotts.LoginAndSingup

data class Customers (//Data to house information of customer
    val uid:String?=null, val Email:String?=null, val Password:String?=null, val Username:String?=null, val Type:String?=null, val WalletAmount:Double?=null)