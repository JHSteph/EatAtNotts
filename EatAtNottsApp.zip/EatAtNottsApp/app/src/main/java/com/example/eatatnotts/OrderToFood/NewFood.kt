package com.example.eatatnotts.OrderToFood

data class NewFood(//Data to house information of Food
    var foodName:String?=null,var price:Double?=null,val photoUrl: String? = "")
