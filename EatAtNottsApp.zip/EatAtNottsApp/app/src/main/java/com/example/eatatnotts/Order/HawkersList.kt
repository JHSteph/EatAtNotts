package com.example.eatatnotts.Order

data class HawkersList(//Data to house information of Hawker
    val username:String?=null, val location:String?=null, val hawkerDescription:String?=null)
