package com.example.eatatnotts.Home

data class News(//News to house data of news in Home
    var Author:String?=null,var ActivityName:String?=null,var Description:String?=null)
