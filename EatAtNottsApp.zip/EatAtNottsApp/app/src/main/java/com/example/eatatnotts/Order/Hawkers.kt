package com.example.eatatnotts.Order

data class Hawkers (//Data to house information of Hawkers in Firebase
    val uid:String?=null, val Email:String?=null, val Password:String?=null, val Username:String?=null, val Type:String?=null)
